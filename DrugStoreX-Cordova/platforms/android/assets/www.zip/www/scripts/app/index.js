
;define(["jquery","cordovaPluginCompat"], function ($,cordovaPluginCompat) {
    $("#sayHi1").unbind("click").click(function(e){
        alert("测试Browser的按钮点击");
    });

    $("#sayHi2").unbind("click").click(function(e){
        cordovaPluginCompat.alert("测试Native的alert");
    });

    $("#sayHi3").unbind("click").click(function(e){
        cordovaPluginCompat.confirm("测试Native的confirm");
    });



    $("#barcodeScan1").unbind("click").click(function(e){
        // TODO: 换用Barcode另一版本试试
        // https://github.com/phonegap-build/BarcodeScanner
        // TODO: 优化扫描框（模仿微信）
        // http://blog.csdn.net/mansai/article/details/19115095
        cordovaPluginCompat.alert("测试条形码扫描 － TODO");
        cordovaPluginCompat.barcodeScan(
            function(result){
                cordovaPluginCompat.alert(result);
            },
            function(error){
                cordovaPluginCompat.alert(error);
            }
        );
    });

    $("#barcodeScan2").unbind("click").click(function(e){
        cordovaPluginCompat.alert("测试二维码扫描 － TODO");
        cordovaPluginCompat.barcodeScan(
            function(result){
                cordovaPluginCompat.alert(result);
            },
            function(error){
                cordovaPluginCompat.alert(error,function () { },"出错了");
            }
        );
    });

    $("#barcodeScan3").unbind("click").click(function(e){
        cordovaPluginCompat.alert("兼容性扫描");
        cordovaPluginCompat.barcodeScan(
            function(result){
                cordovaPluginCompat.alert(result);
            },
            function(error){
                cordovaPluginCompat.alert(error,function () { },"出错了");
            }
        );
    });

    $("#cleanCacheBtn").unbind("click").click(function(e){
        navigator.app.clearCache();
        cordovaPluginCompat.alert("已清除缓存");
        cordovaPluginCompat.alert("cordova默认情况下，缓存所有静态资源（不再依赖304，直接不请求）");
    });

    $("#clearHistoryBtn").unbind("click").click(function(e){
        navigator.app.clearHistory();
        cordovaPluginCompat.alert("已清除历史");
        cordovaPluginCompat.alert("这在Main页面和Login页面加载时直接清除历史是有必要的，因为这两个页面都是无法后退的");
    });


    // Register
    // exit app
    document.addEventListener("backbutton", function () {
        cordovaPluginCompat.confirm("确定退出应用？", function (i) {
            if (i === 1) {
                navigator.app.exitApp();
            }
        }, "提示", ["确定", "取消"]);
    }, true);

    // hide splash screen
    if(runInDevice){
        setTimeout(function () {
            cordovaPluginCompat.splash.hide();
        }, 100);
    };
});